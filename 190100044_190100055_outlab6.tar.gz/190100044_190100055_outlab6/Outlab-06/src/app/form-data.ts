export interface Data {
  name: string;
  email: string;
  feedback: string;
  comment: string;
}
